package com.neu.info7255.bigdata_proj.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.neu.info7255.bigdata_proj.constant.Constant;
import com.neu.info7255.bigdata_proj.constant.MessageEnum;
import com.neu.info7255.bigdata_proj.service.KafkaPub;
import com.neu.info7255.bigdata_proj.service.PlanService;
import com.neu.info7255.bigdata_proj.util.MessageUtil;
import com.neu.info7255.bigdata_proj.validator.SchemaValidator;
import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping(value = "/demo/v1")
public class PlanController {

    private static final Logger logger = LoggerFactory.getLogger(PlanController.class);

    private static ObjectMapper objectMapper = new ObjectMapper();

    private static SchemaValidator planSchema = new SchemaValidator();

    private RSAKey rsaPublicJWK;

    @Autowired
    private PlanService planService;


//    @Autowired
//    private ElasticSearchDao elasticSearchDao;

    @Autowired
    private KafkaPub kafkaPub;

    @RequestMapping(value = "/{object}", method = RequestMethod.POST)
    public ResponseEntity<String> create(@RequestHeader HttpHeaders requestHeaders,
                                         @RequestHeader("Authorization") String idToken,
                                         @PathVariable String object,
                                         @RequestBody String reqJson) {
        // authorize
        try {
            if (!ifAuthorized(requestHeaders)) {
                logger.error("TOKEN AUTHORIZATION - token expired");

                String message = MessageUtil.build(MessageEnum.AUTHORIZATION_ERROR);
                return new ResponseEntity<>(message, HttpStatus.BAD_REQUEST);
            }

            logger.info("TOKEN AUTHORIZATION SUCCESSFUL");
        }catch(Exception e) {
            e.printStackTrace();
            String res = "{\"status\": \"Failed\",\"message\": \"Unauthorized\"}";
            return new ResponseEntity<String>(res, HttpStatus.BAD_REQUEST);
        }
        // json schema validation
        JSONObject newPlan = new JSONObject(reqJson);
        try {
            logger.info(reqJson);
            planSchema.validateSchema(newPlan);
        } catch (Exception e) {
            logger.info("VALIDATING ERROR: SCHEMA NOT MATCH - " + e.getMessage());

            String message = MessageUtil.build(MessageEnum.VALIDATION_ERROR, e.getMessage());

            return ResponseEntity.badRequest().body(message);
        }

        String internalKey = object + "_" + newPlan.getString("objectId");

        // check exist
        if (planService.hasKey(internalKey)) {

            String message = MessageUtil.build(MessageEnum.CONFLICT_ERROR);

            return new ResponseEntity<>(message, HttpStatus.CONFLICT);
        }

        logger.info("CREATING NEW DATA: key - " + internalKey + ": " + newPlan.toString());
        planService.savePlan(internalKey, newPlan);


//        kafkaPub.publish("index", newPlan.toString());

        logger.info("CREATING NEW PLAN INDEX: key - " + internalKey + ": " + newPlan.toString());
//        elasticSearchDao.postPlanDoc(newPlan.getString("objectId"), newPlan);

        String message = MessageUtil
                .build(
                        MessageEnum.SAVE_SUCCESS,
                        newPlan.get("objectType") + "_" + newPlan.get("objectId") + " saved");

        return ResponseEntity
                .ok()
                .body(message);
    }

    @RequestMapping(value = "/{object}/{id}", method = RequestMethod.PATCH)
    public ResponseEntity<String> patchPlan(@RequestHeader HttpHeaders requestHeaders,
                                            @RequestHeader(value = "authorization", required = false) String idToken,
                                             @RequestHeader(value = "If-Match", required = false) String ifMatch,
                                             @PathVariable String object,
                                             @PathVariable String id,
                                             @RequestBody String patchPlan) {

        logger.info("PATCHING PLAN: " + object + ":" + id);

        // check authorization
        try{
        if (!ifAuthorized(requestHeaders)){
            logger.error("TOKEN AUTHORIZATION - google token expired");

            String message = MessageUtil.build(MessageEnum.AUTHORIZATION_ERROR);
            return new ResponseEntity<>(message, HttpStatus.BAD_REQUEST);
        }

        logger.info("TOKEN AUTHORIZATION SUCCESSFUL");


        String intervalKey = object + "_" + id;

        // etag check
        String planEtag = planService.getEtag(intervalKey, "eTag");

        if (ifMatch == null) {
            logger.info("HEADER DOES NOT HAVE IF_MATCH");

            String message = MessageUtil.build(MessageEnum.IF_MATCH_MISSING_ERROR);

            return new ResponseEntity<>(message, HttpStatus.PRECONDITION_REQUIRED);
        }

        if (!ifMatch.equals(planEtag)) {
            logger.info("PATCH PLAN CONFLICT");

            String message = MessageUtil.build(MessageEnum.IF_MATCH_ERROR);

            return new ResponseEntity<>(message, HttpStatus.PRECONDITION_FAILED);
        }

        // check plan exist
        if (!planService.hasKey(intervalKey)) {
            logger.info("PATCH PLAN: " + intervalKey + " does not exist");

            String message = MessageUtil.build(MessageEnum.NOT_FOUND_ERROR);

            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body(message);
        }

        // update plan
        JSONObject patchPlanJson = new JSONObject(patchPlan);

        planService.update(intervalKey, patchPlanJson);
        logger.info("PATCH PLAN : " + intervalKey + " updates successfully");

        String message = MessageUtil.build(MessageEnum.PATCH_SUCCESS);

        return ResponseEntity
                .ok()
                .eTag(planEtag)
                .body(message);
        }catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);

        }
    }

    @RequestMapping(value = "/{object}/{id}", method = RequestMethod.PUT)
    public ResponseEntity<String> updatePlan(@RequestHeader HttpHeaders requestHeaders,
            @RequestHeader(value = "authorization", required = false) String idToken,
                                             @RequestHeader(value = "If-Match", required = false) String ifMatch,
                                             @PathVariable String object,
                                             @PathVariable String id,
                                             @RequestBody String putPlan) {
        logger.info("PUTTING PLAN");

        // authorization
        try{
        if (!ifAuthorized(requestHeaders)) {
            logger.error("TOKEN AUTHORIZATION - google token expired");

            String message = MessageUtil.build(MessageEnum.AUTHORIZATION_ERROR);
            return new ResponseEntity<>(message, HttpStatus.BAD_REQUEST);
        }

        logger.info("TOKEN AUTHORIZATION SUCCESSFUL");

        // json schema validation
        JSONObject newPlan = new JSONObject(putPlan);
        try {
            logger.info(putPlan);

            planSchema.validateSchema(newPlan);
        } catch (Exception e) {
            logger.info("VALIDATING ERROR: SCHEMA NOT MATCH - " + e.getMessage());

            return ResponseEntity.badRequest().body(e.getMessage());
        }

        String intervalKey = object + "_" + id;

        // check etag
        String planEtag = planService.getEtag(intervalKey, "eTag");

        if (ifMatch == null) {
            logger.info("HEADER DOES NOT HAVE IF_MATCH");

            String message = MessageUtil.build(MessageEnum.IF_MATCH_MISSING_ERROR);

            return new ResponseEntity<>(message, HttpStatus.PRECONDITION_REQUIRED);
        }

        if (!ifMatch.equals(planEtag)) {
            logger.info("PUT PLAN CONFLICT");

            String message = MessageUtil.build(MessageEnum.IF_MATCH_ERROR);

            return ResponseEntity
                    .status(HttpStatus.PRECONDITION_FAILED)
                    .eTag(planEtag)
                    .body(message);
        }

        // check plan exist
        if (!planService.hasKey(intervalKey)) {
            logger.info("PUT PLAN: " + intervalKey + " does not exist");

            String message = MessageUtil.build(MessageEnum.NOT_FOUND_ERROR);

            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body(message);
        }

        // delete old plan
        planService.deletePlan(intervalKey);

        // update put plan
        JSONObject putPlanJson = new JSONObject(putPlan);

        planService.savePlan(intervalKey, putPlanJson);
        logger.info("PUT PLAN: " + intervalKey + " updates successfully");

        String message = MessageUtil.build(MessageEnum.PUT_SUCCESS);

        return ResponseEntity
                .ok()
                .eTag(planEtag)
                .body(message);
        }catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);

        }
    }

    @RequestMapping(value = "/{object}/{id}", method = RequestMethod.GET)
    public ResponseEntity<String> readByKey(@RequestHeader HttpHeaders requestHeaders,
            @RequestHeader(value = "Authorization", required = false) String idToken,
                                            @RequestHeader(value = "If-None-Match", required = false) String ifNoneMatch,
                                            @PathVariable String object,
                                            @PathVariable String id) {

        logger.info("RETRIEVING REDIS DATA: " + "object - " + object +
                "; id - " + id);

        String internalKey = object + "_" + id;

        // authorize
        logger.info("AUTHORIZATION: GOOGLE_ID_TOKEN: " + idToken);
try {
    if (!ifAuthorized(requestHeaders)) {
        logger.error("TOKEN AUTHORIZATION - google token expired");

        String message = MessageUtil.build(MessageEnum.AUTHORIZATION_ERROR);
        return new ResponseEntity<>(message, HttpStatus.BAD_REQUEST);
    }

    logger.info("TOKEN AUTHORIZATION SUCCESSFUL");

    if (!planService.hasKey(internalKey)) {
        logger.info("OBJECT NOT FOUND - " + internalKey);

        String message = MessageUtil.build(MessageEnum.NOT_FOUND_ERROR);

        return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
    }

    Map<String, Object> foundValue;
    foundValue = planService.getPlan(internalKey);

    // e-tag
    String objectEtag = planService.getEtag(internalKey, "eTag");

    if (objectEtag.equals(ifNoneMatch)) {
        logger.info("CACHING AVAILABLE: " + internalKey);

        String message = MessageUtil.build(MessageEnum.IF_MATCH_ERROR);

        return new ResponseEntity<>(message, HttpStatus.NOT_MODIFIED);
    }

    logger.info("OBJECT FOUND - " + internalKey);
    try {

        String value = objectMapper.writeValueAsString(foundValue);

        return ResponseEntity
                .ok()
                .eTag(objectEtag)
                .cacheControl(CacheControl.maxAge(24, TimeUnit.HOURS))
                .body(value);

    } catch (JsonProcessingException e) {
        e.printStackTrace();
    }

    return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
}catch (Exception e) {
    e.printStackTrace();
    return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
}
    }

    @RequestMapping(value = "/{object}/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<String> deleteByKey(@RequestHeader HttpHeaders requestHeaders,
                                    @RequestHeader("authorization") String idToken,
                                              @PathVariable String object,
                                              @PathVariable String id) {

        logger.info("DELETING OBJECT: " + object + ", id - " + id);

        // authorize
        logger.info("AUTHORIZATION: GOOGLE_ID_TOKEN: " + idToken);
try {
    if (!ifAuthorized(requestHeaders)) {
        logger.error("TOKEN AUTHORIZATION - google token expired");

        String message = MessageUtil.build(MessageEnum.AUTHORIZATION_ERROR);
        return new ResponseEntity<>(message, HttpStatus.BAD_REQUEST);
    }

    logger.info("TOKEN AUTHORIZATION SUCCESSFUL");

    String intervalKey = object + "_" + id;

    if (!planService.hasKey(intervalKey)) {
        String message = MessageUtil.build(MessageEnum.NOT_FOUND_ERROR);

        return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
    }

    kafkaPub.publish(Constant.ES_DELETE, id);

    planService.deletePlan(intervalKey);
    logger.info("DELETED SUCCESSFULLY: " + object + "_" + intervalKey);

    String message = MessageUtil.build(MessageEnum.DELETE_SUCCESS);
    return new ResponseEntity<>(message, HttpStatus.OK);
}catch (Exception e){
    e.printStackTrace();
    return new ResponseEntity<>(HttpStatus.BAD_REQUEST);

}
    }
    @GetMapping("/token")
    public ResponseEntity<String> getToken() throws JOSEException, ParseException {
        // RSA signatures require a public and private RSA key pair, the public key
        // must be made known to the JWS recipient in order to verify the signatures
        RSAKey rsaJWK = new RSAKeyGenerator(2048).keyID("123").generate();
        rsaPublicJWK = rsaJWK.toPublicJWK();
        // verifier = new RSASSAVerifier(rsaPublicJWK);

        // Create RSA-signer with the private key
        JWSSigner signer = new RSASSASigner(rsaJWK);

        // Prepare JWT with claims set
        int expireTime = 30000; // seconds

        JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()
                .expirationTime(new Date(new Date().getTime() + expireTime * 1000)) // milliseconds
                .build();

        SignedJWT signedJWT = new SignedJWT(
                new JWSHeader.Builder(JWSAlgorithm.RS256).keyID(rsaJWK.getKeyID()).build(),
                claimsSet);

        // Compute the RSA signature
        signedJWT.sign(signer);

        // To serialize to compact form, produces something like
        // eyJhbGciOiJSUzI1NiJ9.SW4gUlNBIHdlIHRydXN0IQ.IRMQENi4nJyp4er2L
        // mZq3ivwoAjqa1uUkSBKFIX7ATndFF5ivnt-m8uApHO4kfIFOrW7w2Ezmlg3Qd
        // maXlS9DhN0nUk_hGI3amEjkKd0BWYCB8vfUbUv0XGjQip78AI4z1PrFRNidm7
        // -jPDm5Iq0SZnjKjCNS5Q15fokXZc8u0A
        String token = signedJWT.serialize();

        String res = "{\"status\": \"Successful\",\"token\": \"" + token + "\"}";
        return new ResponseEntity<String>(res, HttpStatus.OK);

    }
    private boolean ifAuthorized(HttpHeaders requestHeaders) throws ParseException, JOSEException {
        String token = requestHeaders.getFirst("Authorization").substring(7);
        // On the consumer side, parse the JWS and verify its RSA signature
        SignedJWT signedJWT = SignedJWT.parse(token);

        JWSVerifier verifier = new RSASSAVerifier(rsaPublicJWK);
        // Retrieve / verify the JWT claims according to the app requirements
        if (!signedJWT.verify(verifier)) {
            return false;
        }
        JWTClaimsSet claimset = signedJWT.getJWTClaimsSet();
        Date exp = 	claimset.getExpirationTime();

        // System.out.println(exp);
        // System.out.println(new Date());

        return new Date().before(exp);
    }
}
