package com.neu.info7255.bigdata_proj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BigdataProjApplication {

    public static void main(String[] args) {
        SpringApplication.run(BigdataProjApplication.class, args);
    }

}
