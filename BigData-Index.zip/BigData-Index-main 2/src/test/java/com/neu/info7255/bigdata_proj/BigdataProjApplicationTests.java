package com.neu.info7255.bigdata_proj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BigdataProjApplicationTests {

    @Test
    void contextLoads() {
    }

}
