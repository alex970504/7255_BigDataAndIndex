package com.example.demo;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

import javax.xml.bind.DatatypeConverter;

import org.everit.json.schema.Schema;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PlanController {
	@Autowired
	private StringRedisTemplate redis;
	
	@Autowired
	private JwtTokenProvider tokenProvider;
	
	@Autowired
	private ElasticSearchService es;

	@RequestMapping("/")
	public String index() {
		return "Greetings from Spring Boot!";
	}
	
	@GetMapping ("/gettoken")
    public ResponseEntity<?> authenticateUser() throws NoSuchAlgorithmException {
        String jwt = tokenProvider.generateToken();
        return ResponseEntity.ok(new JWTResponse(true, jwt));
    }
	
	@RequestMapping(method = RequestMethod.GET, value = { "/plan/{planId}" })
	public ResponseEntity<String> get(@PathVariable String planId, @RequestHeader HttpHeaders requestHeaders, 
			 @RequestHeader(value = "If-Match", required = false) String etag) throws Exception {
		String token = retreveToken(requestHeaders);
		if (!tokenProvider.validateToken(token)) {
			return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
		}
		String jsonString = redis.opsForValue().get(planId);
		if (etag != null && !etag.equals(generateETag(jsonString))) {
            return new ResponseEntity<String>(HttpStatus.PRECONDITION_FAILED);
        }

		if (jsonString == null || jsonString.equals("")) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok().eTag(generateETag(jsonString)).body(jsonString);
	}

	@RequestMapping(method = RequestMethod.POST, value = { "/plan/add" })
	public ResponseEntity<String> addJson(@RequestBody String data, @RequestHeader HttpHeaders requestHeaders) throws Exception {
		String token = retreveToken(requestHeaders);
		if (!tokenProvider.validateToken(token)) {
			return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
		}
		
		JSONObject rawSchema = readJsonSchema();
		Schema schema = SchemaLoader.load(rawSchema);

		String msg = "";
		try {
			JSONObject jsonData = new JSONObject(data);
			schema.validate(jsonData);
			redis.opsForValue().set(jsonData.getString("objectId"), data);
			es.runTask(jsonData);
			
			msg = jsonData.getString("objectId");
		} catch (Exception e) {
			msg = e.getMessage();
		}
		return ResponseEntity.ok().body(new JSONObject().put("msg", msg).toString());
	}

	@RequestMapping(method = RequestMethod.DELETE, value = { "/plan/{planId}" })
	public ResponseEntity<String> delete(@PathVariable String planId, @RequestHeader HttpHeaders requestHeaders) throws Exception {
		String token = retreveToken(requestHeaders);
		if (!tokenProvider.validateToken(token)) {
			return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
		}
		boolean result = redis.delete(planId) && es.deleteTask(planId);
		
		return ResponseEntity.ok()
				.body(new JSONObject().put("msg", result ? "success" : "error").toString());
	}

	@RequestMapping(method = RequestMethod.PATCH, value = { "/plan/{planId}" })
	public ResponseEntity<String> patchUpdate(@PathVariable String planId, @RequestBody String data, 
			@RequestHeader HttpHeaders requestHeaders, @RequestHeader(value = "If-Match", required = false) String etag)
			throws Exception {
		String token = retreveToken(requestHeaders);
		if (!tokenProvider.validateToken(token)) {
			return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
		}
		
		if (etag == null) {
            return new ResponseEntity<String>(HttpStatus.PRECONDITION_REQUIRED);
        }
		
		String jsonString = redis.opsForValue().get(planId);
		if (!etag.substring(1, etag.length() - 1).equals(generateETag(jsonString))) {
            return new ResponseEntity<String>(HttpStatus.PRECONDITION_FAILED);
        }
		
		String msg = "sucess";
		String updatedResult = "";
		try {
			JSONObject originalJsonObject = new JSONObject(jsonString);
			JSONObject toUpdateJsonObject = new JSONObject(data);
			JsonUtils util = new JsonUtils();
			Map<String, Object> originalMap = util.toMap(originalJsonObject);
			Map<String, Object> topatchMap = util.toMap(toUpdateJsonObject);
			util.parseForPatch(originalMap, topatchMap);
			updatedResult = new JSONObject(originalMap).toString();
			redis.opsForValue().set(planId, updatedResult);
			es.runTask(new JSONObject(originalMap));
		} catch (Exception e) {
			msg = e.getMessage();
		}
		return ResponseEntity.ok().eTag(generateETag(updatedResult)).body(msg);
	}

	@RequestMapping(method = RequestMethod.PUT, value = { "/plan/{planId}" })
	public ResponseEntity<String> getJson(@PathVariable String planId, @RequestBody String data, @RequestHeader HttpHeaders requestHeaders) throws Exception {
		String token = retreveToken(requestHeaders);
		if (!tokenProvider.validateToken(token)) {
			return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
		}
		JSONObject rawSchema = readJsonSchema();
		Schema schema = SchemaLoader.load(rawSchema);

		String msg = "sucess";
		try {
			JSONObject jsonData = new JSONObject(data);
			if (!planId.equals(jsonData.getString("objectId"))) {
				msg = "unmatched object by objectId";
			} else {
				schema.validate(jsonData);
				redis.opsForValue().set(planId, data);
				es.runTask(jsonData);
			}
		} catch (Exception e) {
			msg = e.getMessage();
		}
		return ResponseEntity.ok().body(msg);
	}

	private JSONObject readJsonSchema() {
		InputStream inputStream = getClass().getResourceAsStream("./use case schema.json");
		BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
		return new JSONObject(new JSONTokener(in));
	}

	private String retreveToken(HttpHeaders requestHeaders) {
		try {
			return requestHeaders.getFirst("Authorization");
		} catch (Exception e) {

		}
		return null;
	}
	
	public String generateETag(String str) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(str.getBytes());
        byte[] digest = md.digest();
        String myHash = DatatypeConverter.printHexBinary(digest).toUpperCase();

        return myHash;
    }
}
