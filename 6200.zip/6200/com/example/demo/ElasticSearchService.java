package com.example.demo;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Iterator;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

@Component
public class ElasticSearchService {
	
	private static final String CUSTERMIZE_RELATION = "es_mapping";

	public void runTask(JSONObject json) {
		appendParentInformation(getMapping(), json, "", "");
	}

	private void save(String parentId, String objectId, JSONObject data) {
		if (objectId == null || objectId.equals("")) {
			return;
		}
		JSONObject newJson = new JSONObject();
		for (String key : data.keySet()) {
			if (key.equals(CUSTERMIZE_RELATION)) {
				newJson.put(CUSTERMIZE_RELATION, data.getJSONObject(CUSTERMIZE_RELATION));
			} else {
				try {
					String value = data.getString(key);
					if (value != null && value.length() > 0) {
						newJson.put(key, value);
					}
				} catch (Exception e) {
					try {
						newJson.put(key, data.getInt(key));
					} catch (Exception e2) {
						e2.printStackTrace();
					}
				}
			}
		}
		String toEs = newJson.toString();

		String indexer = "/plan/_doc/" + objectId;
		if (parentId != null) {
			indexer += "?routing=" + parentId;
		}
		try {
			URL url = new URL("http", "127.0.0.1", 9200, indexer);
			CloseableHttpClient httpClient = HttpClients.createDefault();
			HttpPost postRequest = new HttpPost(url.toURI());
			StringEntity entity = new StringEntity(toEs, ContentType.APPLICATION_JSON);
			postRequest.setEntity(entity);
			httpClient.execute(postRequest);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void appendParentInformation(JSONObject preDefinedMapping, Object objJson, String parentType, String parentId) {
		if (parentType.equals(CUSTERMIZE_RELATION)) {
			return;
		}

		if (objJson instanceof JSONArray) {
			JSONArray objArray = (JSONArray) objJson;
			for (int i = 0; i < objArray.length(); i++) {
				appendParentInformation(preDefinedMapping, objArray.get(i), parentType, parentId);
			}
		}
		else if (objJson instanceof JSONObject) {
			JSONObject jsonObject = (JSONObject) objJson;

			String objType = jsonObject.optString("objectType");
			String objId = jsonObject.optString("objectId");

			if (!preDefinedMapping.isNull(objType)) {
				jsonObject.put(CUSTERMIZE_RELATION, new JSONObject().put("name", objType));
			}
			for (String preKey : preDefinedMapping.keySet()) {
				if (!preDefinedMapping.isNull(preKey) && preDefinedMapping.optString(preKey).equals(objType)) {
					jsonObject.put(CUSTERMIZE_RELATION, new JSONObject().put("name", objType).put("parent", parentId));
				} else {
					JSONArray array = preDefinedMapping.getJSONArray(preKey);
					for (int i = 0; i < array.length(); i++) {
						if (array.getString(i).equals(objType)) {
							jsonObject.put(CUSTERMIZE_RELATION, new JSONObject().put("name", objType).put("parent", parentId));
						}
					}
				}
			}

			save(parentId, objId, jsonObject);

			Iterator it = jsonObject.keys();
			while (it.hasNext()) {
				String key = it.next().toString();
				Object object = jsonObject.get(key);
				if (object instanceof JSONArray) {
					JSONArray objArray = (JSONArray) object;
					appendParentInformation(preDefinedMapping, objArray, objType, objId);
				}
				else if (object instanceof JSONObject) {
					appendParentInformation(preDefinedMapping, (JSONObject) object, objType, objId);
				}
			}
		}
	}

	public JSONObject getMapping() {
		try {
			URL url = new URL("http", "127.0.0.1", 9200, "/plan/_mapping/field/" + CUSTERMIZE_RELATION);
			CloseableHttpClient httpClient = HttpClients.createDefault();
			HttpGet getRequest = new HttpGet(url.toURI());
			CloseableHttpResponse httpResponse = httpClient.execute(getRequest);
			String ret = EntityUtils.toString(httpResponse.getEntity());
			JSONObject json = new JSONObject(ret);
			JSONObject map = json.getJSONObject("plan").getJSONObject("mappings").getJSONObject(CUSTERMIZE_RELATION)
					.getJSONObject("mapping").getJSONObject(CUSTERMIZE_RELATION).getJSONObject("relations");
			return map;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	public boolean deleteTask(String objectId) {

		try {
			String indexer = "/plan/_doc/" + objectId;
			URL url = new URL("http", "127.0.0.1", 9200, indexer);
			CloseableHttpClient httpClient = HttpClients.createDefault();
			HttpDelete deleteRequest = new HttpDelete(url.toURI());
			httpClient.execute(deleteRequest);
			return true;
		} catch (URISyntaxException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

}
