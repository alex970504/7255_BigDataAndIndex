package com.example.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JsonUtils {
	public void parseForPatch(Map<String, Object> planMap, Map<String, Object> patchMap) throws JSONException {
		if (planMap.get("objectId").equals(patchMap.get("objectId"))) {
			for (String key : planMap.keySet()) {
				Object val = planMap.get(key);
				if (val instanceof Map) {
					if (patchMap.containsKey(key)) {
						boolean changed = handlePatch((Map) planMap.get(key), (Map) patchMap.get(key));
						if (!changed) {
							if (planMap.get(key) instanceof Map) {
								Object tmp = planMap.get(key);
								planMap.put(key, Arrays.asList(tmp, patchMap.get(key)));
							} else {
								((List<Object>) planMap.get(key)).add(patchMap.get(key));
							}
						}
					}
				}
			}
		} else {
			for (String key : planMap.keySet()) {
				Object val = planMap.get(key);
				if (val instanceof List) {
					List<Map<String, Object>> list = new ArrayList<>();
					for (Map map : (List<Map>) val) {
						parseForPatch(map, patchMap);
					}
				} else if (val instanceof Map) {
					parseForPatch((Map) val, patchMap);
				}
			}
		}
	}

	public boolean handlePatch(Map<String, Object> planMap, Map<String, Object> patchMap) throws JSONException {
		boolean exist = false;
		if (planMap.get("objectId").equals(patchMap.get("objectId"))) {
			exist = true;
			for (String key : planMap.keySet()) {
				if (!planMap.get(key).equals(patchMap.get(key))) {
					planMap.put(key, patchMap.get(key));
				}
			}
		}
		return exist;
	}

	public Map<String, Object> toMap(JSONObject jsonobj) throws JSONException {
		Map<String, Object> map = new HashMap<String, Object>();
		Iterator<String> keys = jsonobj.keys();
		while (keys.hasNext()) {
			String key = keys.next();
			Object value = jsonobj.get(key);
			if (value instanceof JSONArray) {
				value = toList((JSONArray) value);
			} else if (value instanceof JSONObject) {
				value = toMap((JSONObject) value);
			}
			map.put(key, value);
		}
		return map;
	}

	public List<Object> toList(JSONArray array) throws JSONException {
		List<Object> list = new ArrayList<Object>();
		for (int i = 0; i < array.length(); i++) {
			Object value = array.get(i);
			if (value instanceof JSONArray) {
				value = toList((JSONArray) value);
			} else if (value instanceof JSONObject) {
				value = toMap((JSONObject) value);
			}
			list.add(value);
		}
		return list;
	}
}
